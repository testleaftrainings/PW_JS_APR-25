import { BrowserContext, Page } from "playwright"
import test from "playwright/test"

export abstract class PWWrapper {

    page: Page
    context: BrowserContext

    constructor(page: Page) {
        this.page = page
    }

    async typeAndTab(locator: string, data: string) {
        await this.page.fill(locator, data)
        await this.page.press(locator, 'Tab')
    }

    async clearandType(locator: string, data: string, name: string) {
        try {
            test.step(`Clear the field and enter with ${data} in ${name}`, async () => {
                const ele = this.page.locator(locator)
                await ele.clear()
                await ele.fill(data)
            })
        } catch (error) {
            console.log(error)
            throw new Error()
        }

    }
async type(locator: string, data: string, name: string) {
        try {
            test.step(`Clear the field and enter with ${data} in ${name}`, async () => {
                const ele = this.page.locator(locator)
                await ele.fill(data)
            })
        } catch (error) {
            console.log(error)
            throw new Error()
        }

    }

    async handleWindow(locator: string): Promise<Page> {
        const handle = this.context.waitForEvent('page')
        this.page.locator(locator).click()
        const promise = await handle
        return promise
    }





}