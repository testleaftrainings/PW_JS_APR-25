export const selectors={
        usernameField:"#username",
        PwdField:"#password",
        login_logout:".decorativeSubmit",
        crmLink:"text=CRM/SFA",
        modName:(modName:string)=>`//a[text()='${modName}']`,
        Leads:{
          firstname:`#createLeadForm_companyName`
        },
        Accounts:{

        }
}