import test from "playwright/test";
import { ViewLeadPage } from "../../pages/vieLeadPage";


test(`CreateAccount verification`,async({page})=>{
   const vp=new ViewLeadPage(page)
   await vp.loadUrl()
   await vp.enterCredentials()
   await vp.clickLogin()
   await vp.clickCrm()
   await vp.clickAccounts()
})