import { test } from "../utils/customFixture";


test(`Login verification`,async({login})=>{
  console.log("Login is sucessful")
    
})