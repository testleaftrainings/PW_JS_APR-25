import { chromium, Page } from "@playwright/test";
import { selectors } from "../utils/locators";
import { PWWrapper } from "../utils/playwrightWrapper";

export class LFLoginFuntionality extends PWWrapper{

      //  public selectors={
    //     "usernameField":"#username",
    //     "PwdField":"#password",
    //     "login_logout":".decorativeSubmit",
    //     "crmLink":"text=CRM/SFA",
    //     "LeadMod":`//a[text()='Leads']`

    //  }

    async loadUrl(url:string) {
        await this.page.goto(url)
    }

    async enterCredentials(username:string,password:string) {
        await this.type(selectors.usernameField,username,"Username")
        await this.type(selectors.PwdField, password,"Password")
    }

    async clickLogin() {
        await this.page.click(selectors.login_logout)
        //await this.handleWindow(selectors.modName(''))
    
    }

}