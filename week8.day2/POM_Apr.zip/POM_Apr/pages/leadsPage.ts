
import { HomePage } from "./homePage";
import { selectors } from "../utils/locators";

export class LeadsPage extends HomePage{

    async clickCreateLead(){
            await this.page.click(selectors.modName('Create Lead'))
    }
    async clickMergeLead(){

    }


    async clickFindLead(){

     }

}