import { CreateLeadPage } from "./createLead";

export class ViewLeadPage extends CreateLeadPage{
 

    async verifyFirstname(){
    //   const fname= await this.page.innerText("viewLead_firstName_sp")
      console.log("Lead created")
       //assertion
    }


}