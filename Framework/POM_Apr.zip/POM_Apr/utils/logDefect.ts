import { TestInfo } from "playwright/test";
import { createIssue } from "./jiraAPi";

export async function logaDefect(testinfo:TestInfo){
   const isBug= testinfo.annotations.some(annotation=>annotation.type=="Bug")
    if(testinfo.status=="timedOut" && isBug || testinfo.status=="failed" && isBug){
        const summary =`The test  ${testinfo.title} is ${testinfo.status}`
        const desc=`The failure is due to ${testinfo.error?.message}`
        const proKey= await createIssue(summary,desc)
      return proKey
    }

}