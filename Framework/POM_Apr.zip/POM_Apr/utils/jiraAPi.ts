import axios from "axios"

//endpoint
let endpoint="https://vidya-bharathi.atlassian.net/rest/api/2/issue"
let userId="vidyar1926@gmail.com"
let token="ATATT3xFfGF0qtlQNopmNYGGNNQdfSRYjmIxHRBQYfgSHgLqZny1TR-hHAWNvBri878L7MliVFE4L2lvYlRYHK01KHU83GyCDbJinoPL2ZwAk8Q3Vf39ILMpOHzFAbUbzN-wuXcDRAYA_tYTBqUkBdhgwqeM8rPwBFwSNVrGlofPwOtJZm70S_4=028B78B7"
let projectKey="PAPR"

export async function createIssue(summary:string,description:string){
  const issueBody={
     "fields":{
        "project":{
            "key":projectKey
           },
          "issuetype":{
            "name":"Bug"
          },
         "summary":summary,
         "description":description,
        //  "assignee":{
        //     "name":""
        //  }
        "priority":{
            "name":"High"
        }

     }
  }

    const response= await axios.post(endpoint,issueBody,{
        headers:{
            "Content-Type":"application/json"
        },
        auth:{
            "username":userId,
            "password":token
        }
    })     
 
 return response.data.key
}

//createIssue("TC001_LoginPage","Login button is not functioning")