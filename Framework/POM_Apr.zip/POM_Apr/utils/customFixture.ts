import { test as baseTest } from '@playwright/test'
import { LFLoginFuntionality } from '../pages/loginPage'
import { WelcomePage } from '../pages/welcomePage'
import { HomePage } from '../pages/homePage'
import { LeadsPage } from '../pages/leadsPage'
import { CreateLeadPage } from '../pages/createLead'
import { ViewLeadPage } from '../pages/vieLeadPage'
import { createIssue } from './jiraAPi'
import { logaDefect } from './logDefect'


type myFixtures = {
    login: LFLoginFuntionality,
    wp: WelcomePage,
    hp: HomePage
    leadsPage: LeadsPage,
    clPage: CreateLeadPage
    vp: ViewLeadPage
}

export const test = baseTest.extend<myFixtures>({

    login: async ({ page }, use) => {
        const lop = new LFLoginFuntionality(page)
        await lop.loadUrl("http:leaftaps.com/opentaps/control/main")
        await lop.enterCredentials("demoCSR", "crmsfa")
        await lop.clickLogin()
        await page.context().storageState({ path: "data/loginsession.json" })
        await use(lop)
        
    },

    wp: async ({ page }, use) => {
        const wp = new WelcomePage(page)
        await use(wp)
    },
    hp: async ({ page }, use) => {
        const hp = new HomePage(page)
        await use(hp)
    },
    leadsPage: async ({ page }, use) => {
        const lp = new LeadsPage(page)
        await use(lp)
    },
    clPage: async ({ page }, use) => {
        const cp = new CreateLeadPage(page)
        await use(cp)
    },
    vp: async ({ page }, use) => {
        const vp = new ViewLeadPage(page)
        await use(vp)
    }


})

let key:any
test.afterEach(`Create a defect`,async({},testInfo)=>{
 key = await logaDefect(testInfo)
  console.log(key)
})


test.afterAll(`upload attachments`,async()=>{
    console.log("upload the attachement " +key)
})