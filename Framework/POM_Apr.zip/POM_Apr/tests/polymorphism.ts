export class ElementAction{


   public static clickEle(locator:string,forceClick:boolean | undefined=true,timeout?:number){
          if(forceClick== true){
             console.log(`forcibly click the element using the locator: ${locator} with ${timeout}` )
          }else{
            console.log("Click element normally")
          }
   }

   public cal(value:number):void
   public cal(funname:string,value:number):void

   //actual impln
   public cal(val:any,funNa?:any){

   }


}


//const obj=new ElementAction()
ElementAction.clickEle("")

export class Page{

    constructor(){
        this.launchBrowser()
        console.log("Create page instance")
    }

    launchBrowser(){
        console.log("Launching chrome")
    }
}

export class BaseClass extends Page{

constructor(){
    super()
    super.launchBrowser()
}
 launchBrowser(){
       console.log("Launching Edge Browser")
 }

  login(){
    console.log("enter with valid credentials")
  }
//super to call the parent class methods/property /constructor
}

const bc=new BaseClass()
bc.login()