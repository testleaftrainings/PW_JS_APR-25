"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseClass = exports.Page = exports.ElementAction = void 0;
var ElementAction = /** @class */ (function () {
    function ElementAction() {
    }
    ElementAction.clickEle = function (locator, forceClick, timeout) {
        if (forceClick === void 0) { forceClick = true; }
        if (forceClick == true) {
            console.log("forcibly click the element using the locator: ".concat(locator, " with ").concat(timeout));
        }
        else {
            console.log("Click element normally");
        }
    };
    //actual impln
    ElementAction.prototype.cal = function (val, funNa) {
    };
    return ElementAction;
}());
exports.ElementAction = ElementAction;
//const obj=new ElementAction()
ElementAction.clickEle("");
var Page = /** @class */ (function () {
    function Page() {
        this.launchBrowser();
        console.log("Create page instance");
    }
    Page.prototype.launchBrowser = function () {
        console.log("Launching chrome");
    };
    return Page;
}());
exports.Page = Page;
var BaseClass = /** @class */ (function (_super) {
    __extends(BaseClass, _super);
    function BaseClass() {
        var _this = _super.call(this) || this;
        _super.prototype.launchBrowser.call(_this);
        return _this;
    }
    BaseClass.prototype.launchBrowser = function () {
        console.log("Launching Edge Browser");
    };
    BaseClass.prototype.login = function () {
        console.log("enter with valid credentials");
    };
    return BaseClass;
}(Page));
exports.BaseClass = BaseClass;
var bc = new BaseClass();
bc.login();
