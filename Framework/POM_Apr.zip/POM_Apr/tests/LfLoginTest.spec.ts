import { test } from "../utils/customFixture";
import { createIssue } from "../utils/jiraAPi";


test(`Login verification`,async({login,vp},testInfo)=>{
  test.info().annotations.push({type:"Bug",description:testInfo.title})
  console.log("Login is sucessful")
  await vp.clickCrm()
   })
