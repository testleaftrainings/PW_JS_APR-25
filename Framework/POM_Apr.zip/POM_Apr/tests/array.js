var numbers = [1, 2, 3, 4, 5, 6];
var evens = numbers.filter(function (num) { return num % 2 === 0; });
console.log(evens);
