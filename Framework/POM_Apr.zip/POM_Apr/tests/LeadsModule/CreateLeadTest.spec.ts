import { test } from "../../utils/customFixture";

//test.use({storageState:"data/loginsession.json"})
test(`CreateLead verification`,async({login,vp})=>{   
   await vp.clickCrm()
   await vp.clickLead()
   await vp.clickCreateLead()
   await vp.enterMandarydetails()
   await vp.clickSubmit()
   await vp.verifyFirstname()
})