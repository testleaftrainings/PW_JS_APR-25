import { Page } from "@playwright/test";
import { LFLoginFuntionality } from "./loginPage";
import { selectors } from "../utils/locators";

export class WelcomePage extends LFLoginFuntionality{

    async clickCrm(){
     // await this.page.goto("http://leaftaps.com/opentaps/control/login")
      await this.page.click(selectors.crmLink)
    }

    async clickLogout(){
        await this.page.click(selectors.login_logout)
    }


}