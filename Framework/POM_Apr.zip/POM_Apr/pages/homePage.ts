import { selectors } from "../utils/locators";
import { WelcomePage } from "./welcomePage";

export class HomePage extends WelcomePage{


 async clickLead(){
    await this.page.click(selectors.modName('Leads'))
 }
 
 async clickAccounts(){
    await this.page.click(selectors.modName('Accounts'))
 }
 
 async clickContacts(){
    await this.page.click(selectors.modName('Contacts'))
 }
 
 async clickOpportunity(){
    await this.page.click(selectors.modName('Opportunities'))
 }

}