import { faker } from "@faker-js/faker";
import { LeadsPage } from "./leadsPage";
import { selectors } from "../utils/locators";

export class CreateLeadPage extends LeadsPage{
 
    async enterMandarydetails(){
        await this.page.fill(selectors.Leads.firstname,faker.company.buzzNoun())
        await this.page.fill("#createLeadForm_firstName",faker.person.firstName())
        await this.page.fill("#createLeadForm_lastName",faker.person.lastName())
    }

    async clickSubmit(){
        await this.page.click(".smallSubmit")
    }

}