import { After, AfterStep, Before, setWorldConstructor, World } from "@cucumber/cucumber";
import { Browser, chromium, Page } from "@playwright/test";
//World -->container -->stores the objects
export class MyCustomFeature extends World{

 browser!:Browser;
 page!:Page;

  async initBrowser(){
    this.browser=await chromium.launch({headless:false})
    this.page=await this.browser.newPage()
  }

  async closeBrowser(){
    await this.page.close()
  }    
}

setWorldConstructor(MyCustomFeature) //page & browser across the steps


Before(async function(){
    await this.initBrowser()
})

AfterStep(async function(){  
  await this.page.screenshot({path:`data/screenshot ${new Date().getMilliseconds()}.png`})
})

After(async function(){
    await this.closeBrowser()
})
