import { Then } from "@cucumber/cucumber";

Then('Verify the homepage', async function () {
       console.log(await this.page.title())
           console.log("title is verified")
          
         });