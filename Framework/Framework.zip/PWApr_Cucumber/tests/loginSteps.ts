import { Given, Then, When } from "@cucumber/cucumber";

        Given('Load the url', async function () {                  
          await this.page.goto("http://leaftaps.com/opentaps/control/main")
          });

         Given('Enter the credentials as {string} and {string}', async function (username:string,password:string) {
           await this.page.fill("#username",username)
           await this.page.fill("#password",password)
         });

         Given('Enter the credentials', async function () {  //first feature file
           await this.page.fill("#username","DemoCSR")
           await this.page.fill("#password","crmsfa")
         });

          When('I Click on Login button', async function () {
            await this.page.click(".decorativeSubmit")
         });

     