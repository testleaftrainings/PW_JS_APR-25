export enum credentialConstants {
    USERNAME = 'majay3574@gmail.com',
    PASSWORD = 'Ajaymichael@321',
}