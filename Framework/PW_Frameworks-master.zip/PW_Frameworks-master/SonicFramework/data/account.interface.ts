export interface accountData {
    TC001?: string;
}